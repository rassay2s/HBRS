package org.hbrs.se1.ss24.uebung1.client;

import org.hbrs.se1.ss24.uebung1.businesslogic.RomanNumberTransformer;

public class Factory{

   public static RomanNumberTransformer create(){
       RomanNumberTransformer a = new RomanNumberTransformer();
       return a;
   }

}
