package org.hbrs.se1.ss24.uebung1.businesslogic;

public interface NumberTransformer {
    String transformNumber(int number);

        String getTransformerType();
}