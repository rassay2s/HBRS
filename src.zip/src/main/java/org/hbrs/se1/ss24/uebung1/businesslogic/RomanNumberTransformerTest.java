package org.hbrs.se1.ss24.uebung1.businesslogic;

import org.hbrs.se1.ss24.uebung1.client.Client;
import org.hbrs.se1.ss24.uebung1.client.Factory;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.*;

class RomanNumberTransformerTest {
    RomanNumberTransformer r;
    Factory factory = new Factory();
    RomanNumberTransformer t;

    @BeforeEach
    void setup(){
        t = factory.create();
    }


    @Test
    void transformNumber() {
        assertEquals("I", t.transformNumber(1));
        assertEquals("IV", t.transformNumber(4));
        assertEquals("V", t.transformNumber(5));
        assertEquals("IX", t.transformNumber(9));
        assertEquals("X", t.transformNumber(10));
        assertEquals("XL", t.transformNumber(40));
        assertEquals("LV", t.transformNumber(55));
        assertEquals("XCIX", t.transformNumber(99));
        assertEquals("C", t.transformNumber(100));
        assertEquals("CD", t.transformNumber(400));
        assertEquals("DI", t.transformNumber(501));
        assertEquals("CM", t.transformNumber(900));
        assertEquals("M", t.transformNumber(1000));
        assertThrows(IndexOutOfBoundsException.class, ()-> t.transformNumber(10000000) );
        assertThrows(IndexOutOfBoundsException.class, ()-> t.transformNumber(-1000) );
        assertThrows(IndexOutOfBoundsException.class, ()-> t.transformNumber(0) );
    }
}