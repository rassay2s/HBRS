package org.hbrs.se1.ss24.uebung1.client;

import org.hbrs.se1.ss24.uebung1.businesslogic.GermanFormatNumberTransformer;

import java.io.PrintStream;

public class Client {
    private Factory a = null;
    public void printTransformation(int number) {


        String result = ""; // Hier fehlt noch was
        result = a.create().transformNumber(number);

        System.out.println("Die römische Schreibweise der Zahl " + number + " ist: " + result);
    }

    public static void main(String[] args) {
        Client a = new Client();
        a.printTransformation(99);
    }
}
