package org.hbrs.se1.ss24.uebung1.businesslogic;

import org.hbrs.se1.ss24.uebung1.client.Client;

public class RomanNumberTransformer implements NumberTransformer {
    @Override
    public String transformNumber(int number) throws IndexOutOfBoundsException {
        String s = "";
        String[] romanSymbols = {"I", "IV", "V", "IX", "X", "XL", "L", "XC", "C", "CD", "D", "CM", "M"};
        int[] romanValues = {1, 4, 5, 9, 10, 40, 50, 90, 100, 400, 500, 900, 1000};
        if (number > 3000 || number < 1) {
            throw new IndexOutOfBoundsException();
        }
        while (true) {
            if (number >= 1000) {
                number -= 1000;
                s += "M";
                if (number == 0) {
                    break;
                }
                continue;
            }
            if (number >= 900) {
                number -= 900;
                s += "CM";
                if (number == 0) {
                    break;
                }
                continue;
            }
            if (number >= 500) {
                number -= 500;
                s += "D";
                if (number == 0) {
                    break;
                }
                continue;

            }
            if (number >= 400) {
                number -= 400;
                s += "CD";
                if (number == 0) {
                    break;
                }
                continue;

            }
            if (number >= 100) {
                number -= 100;
                s += "C";
                if (number == 0) {
                    break;
                }
                continue;

            }
            if (number >= 90) {
                number -= 90;
                s += "XC";
                if (number == 0) {
                    break;
                }
                continue;

            }
            if (number >= 50) {
                number -= 50;
                s += "L";
                if (number == 0) {
                    break;
                }
                continue;

            }
            if (number >= 40) {
                number -= 40;
                s += "XL";
                if (number == 0) {
                    break;
                }
                continue;

            }
            if (number >= 10) {
                number -= 10;
                s += "X";
                if (number == 0) {
                    break;
                }
                continue;

            }
            if (number >= 9) {
                number -= 9;
                s += "IX";
                if (number == 0) {
                    break;
                }
                continue;

            }
            if (number >= 5) {
                number -= 5;
                s += "V";
                if (number == 0) {
                    break;
                }
                continue;

            }
            if (number >= 4) {
                number -= 4;
                s += "IV";
                if (number == 0) {
                    break;
                }
                continue;

            }
            if (number >= 1) {
                number -= 1;
                s += "I";
                if (number == 0) {
                    break;
                }
                continue;

            }
        }
        return s;
    }

    public String transformNumber1(int number) throws IndexOutOfBoundsException {
        String[] romanSymbols = {"I", "IV", "V", "IX", "X", "XL", "L", "XC", "C", "CD", "D", "CM", "M"};
        int[] romanValues = {1, 4, 5, 9, 10, 40, 50, 90, 100, 400, 500, 900, 1000};
        //int number = 1234;
        StringBuilder romanNumeral = new StringBuilder();
         for (int i = romanValues.length - 1; i >= 0; i--) {

         while (number >= romanValues[i]) { romanNumeral.append(romanSymbols[i]); number -= romanValues[i]; } }
          String result = romanNumeral.toString();
        return result;
    }

    public static void main(String[] args) {
        RomanNumberTransformer s = new RomanNumberTransformer();
        System.out.println(s.transformNumber1(2465));
        Client c = new Client();

    }

    @Override
    public String getTransformerType() {
        return "Transformer für römische Zahlen";
    }
}
