package org.hbrs.se1.ss24.uebung1.businesslogic;

public class GermanFormatNumberTransformer implements NumberTransformer{
    @Override
    public String transformNumber(int number) {
        String s = "";
        StringBuilder punkt = new StringBuilder();
        s += punkt.append(  number);
        if(number > 3000 || number < 1){
            throw new IndexOutOfBoundsException();
        }
        if ( number >= 1000){
            s= s.charAt(0) + "." + s.substring(1,s.length());
        }
        return s;
    }

    public static void main(String[] args) {
        GermanFormatNumberTransformer s = new GermanFormatNumberTransformer();
        System.out.println(s.transformNumber(1000));
    }

    @Override
    public String getTransformerType() {
        return "Transformer für deutsche Zahlenformatierungen";
    }
}
